import React, { useState } from "react";
import { View, StyleSheet, FlatList, Modal, TextInput } from "react-native";
import TextInputComponent from "../components/TextInputComponent.jsx";
import ButtonComponent from "../components/ButtonComponent.jsx";
import TaskItem from "../components/TaskItem.jsx";
import FilterButtons from "../components/FilterButtons.jsx";

const TaskScreen = () => {
  const [tasks, setTasks] = useState([]);
  const [text, setText] = useState("");
  const [filter, setFilter] = useState("Todas");
  const [editingTask, setEditingTask] = useState(null);

  // Adicionar tarefa
  const addTask = () => {
    if (text.trim()) {
      setTasks([...tasks, { id: Date.now().toString(), text, done: false }]);
      setText("");
    }
  };

  // Marcar como concluída
  const toggleTask = (id) => {
    setTasks(tasks.map((task) =>
      task.id === id ? { ...task, done: !task.done } : task
    ));
  };

  // Remover tarefa
  const removeTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  // Salvar edição
  const saveTask = () => {
    setTasks(tasks.map((task) =>
      task.id === editingTask.id ? { ...task, text: editingTask.text } : task
    ));
    setEditingTask(null);
  };

  // Filtrar tarefas
  const filteredTasks = tasks.filter((task) => {
    if (filter === "Pendentes") return !task.done;
    if (filter === "Concluídas") return task.done;
    return true;
  });

  return (
    <View style={styles.container}>
      {/* Input + botão */}
      <View style={styles.row}>
        <TextInputComponent
          value={text}
          onChangeText={setText}
          placeholder="Digite uma tarefa..."
        />
        <ButtonComponent title="Adicionar" onPress={addTask} />
      </View>

      {/* Filtros */}
      <FilterButtons filter={filter} setFilter={setFilter} />

      {/* Lista */}
      <FlatList
        data={filteredTasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TaskItem
            task={item}
            toggleTask={toggleTask}
            editTask={setEditingTask}
            removeTask={removeTask}
          />
        )}
      />

      {/* Modal de edição */}
      <Modal visible={!!editingTask} animationType="slide" transparent>
        <View style={styles.modal}>
          <TextInput
            style={styles.input}
            value={editingTask?.text}
            onChangeText={(t) => setEditingTask({ ...editingTask, text: t })}
          />
          <ButtonComponent title="Salvar" onPress={saveTask} />
          <ButtonComponent title="Cancelar" onPress={() => setEditingTask(null)} />
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#fff" },
  row: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  input: { borderWidth: 1, borderColor: "#ccc", padding: 8, borderRadius: 5 },
  modal: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#000000aa",
    padding: 20,
  },
});

export default TaskScreen;
