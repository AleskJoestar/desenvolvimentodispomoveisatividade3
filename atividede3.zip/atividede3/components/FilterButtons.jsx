import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

const FilterButtons = ({ filter, setFilter }) => {
  const options = ["Todas", "Pendentes", "Concluídas"];

  return (
    <View style={styles.row}>
      {options.map((f) => (
        <TouchableOpacity key={f} onPress={() => setFilter(f)}>
          <Text style={[styles.filter, filter === f && styles.activeFilter]}>
            {f}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  row: { flexDirection: "row", justifyContent: "center", marginBottom: 10 },
  filter: { marginHorizontal: 10, fontSize: 16 },
  activeFilter: { fontWeight: "bold", color: "#6200ee" },
});

export default FilterButtons;
