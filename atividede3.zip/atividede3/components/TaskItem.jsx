import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import ButtonComponent from "./ButtonComponent";

const TaskItem = ({ task, toggleTask, editTask, removeTask }) => (
  <View style={styles.taskRow}>
    <TouchableOpacity onPress={() => toggleTask(task.id)}>
      <Text style={[styles.task, task.done && styles.done]}>
        {task.text}
      </Text>
    </TouchableOpacity>
    <View style={styles.actions}>
      <ButtonComponent title="Editar" onPress={() => editTask(task)} />
      <ButtonComponent title="Excluir" onPress={() => removeTask(task.id)} />
    </View>
  </View>
);

const styles = StyleSheet.create({
  taskRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
    alignItems: "center",
  },
  task: { fontSize: 16 },
  done: { textDecorationLine: "line-through", color: "#aaa" },
  actions: { flexDirection: "row" },
});

export default TaskItem;
