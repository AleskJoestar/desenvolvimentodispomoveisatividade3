import React from "react";
import TaskScreen from "./screens/TaskScreen.jsx";

export default function App() {
  return <TaskScreen />;
}
